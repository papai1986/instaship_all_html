// JavaScript Document
var btn = document.getElementById('show-hide-btn');
var Window = document.getElementById('modal');
var body = document.getElementById('body');

btn.onclick= function(){
	Window.classList.add('visibility');
	body.classList.add('show_modal');
}// JavaScript Document