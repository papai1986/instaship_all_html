$(document).ready(function() {
    var dataTable = $('#data_table').DataTable({
        "pageLength":10,
        "bLengthChange":false,
        "bFilter":false,
        "bAutoWidth":false
        //"bInfo":false
    });

    $('#filter_search').keyup(function(){
        dataTable.search(this.value).draw();
    });
} );