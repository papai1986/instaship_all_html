var taggle_btn = document.querySelector('#toogle-btn');
var taggle_class = document.querySelector('.navbar');
var toggle_search= document.querySelector('.search-box');
var toggle_body= document.querySelector('.task-content');
taggle_btn.onclick = function(){
    taggle_class.classList.toggle('hide');
	toggle_search.classList.toggle('hide');
	toggle_body.classList.toggle('hide');
}
