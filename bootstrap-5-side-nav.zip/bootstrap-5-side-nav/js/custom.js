var taggle_btn = document.querySelector('#toogle-btn');
var taggle_class = document.querySelector('.navbar');

taggle_btn.onclick = function(){
    taggle_class.classList.toggle('hide');
}
